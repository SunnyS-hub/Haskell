/*
 * DynamicArray.h
 *
 *  Created on: 20 Nov 2019
 *      Author: SUnNY
 */

#ifndef SRC_DYNAMIC_H
#define SRC_DYNAMIC_H

#include <iostream>
using namespace std;

template <class T>
class DynamicArray
{
public:
	int size;
	T *elements;
	int currentNumberOfElements;


	DynamicArray(int arrSize); //NEED COPY CONSTRUCTOR
	DynamicArray(const DynamicArray &old);
	int ReturnNumberOfElementsInArray();
	T returnElementSpecified(); //USE OPERATOR []
	void AddElement(T elem);
	void printAllElements();
	//~DynamicArray(); //NEED COPY DESTRUCTOR
};

#endif






//template <class T>
//class DynamicArray
//{
//	int size=0;
//	T elements[] = calloc(size, sizeof(T)); // MAYBE USE CALLOC ?????
//	int currentNumberOfElements=0;
//
//public:
//	DynamicArray(int arrSize){
//		size = arrSize;
//	}
//
//	int returnNumOfElementsInArray(){
//		return currentNumberOfElements;
//	}
//
//	void AddElement(T elemToAdd){
//		T * PTRarr = elements;
//		PTRarr+=(size-(currentNumberOfElements+1));
//		if(currentNumberOfElements != size && sizeof(T) != 1){
//			*PTRarr = elemToAdd;
//			currentNumberOfElements++;
//		}
//	}
//	void printAllElements(){
//		T * PTRarr = elements;
//		int empty = size - currentNumberOfElements;
//		PTRarr+= empty;
//		for(int i = 0 ; i<(currentNumberOfElements-1); i++ ){
//			cout << *(PTRarr+i) << endl;
//		}
//	}
//	void TestMethod();
//	void TestMethod2();
//	~DynamicArray();
//
//};
