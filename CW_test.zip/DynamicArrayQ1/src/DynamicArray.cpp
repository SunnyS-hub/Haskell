/*
 * DynamicArray.cpp
 *
 *  Created on: 20 Nov 2019
 *      Author: SUnNY
 */
#include "DynamicArray.h"


template<class T>
DynamicArray<T>::DynamicArray(int arrSize){
	size = arrSize;
	elements = new T[size];
	currentNumberOfElements = 0;
}

template<class T>
DynamicArray<T>::DynamicArray(const DynamicArray &old){
	cout << "copy constructor running" << endl;
	size = (old.size * 2);
	elements = new T[size];
	currentNumberOfElements = 0;
	//copy elements from old to new
	int counter = 0; // CAN USE CLASS MEMBER CURRENT_NUMBER_OF_ELEMENTS INSTEAD
	while(counter<old.size){
		elements[(size-1)-counter] = old.elements[counter];
		counter ++;
		currentNumberOfElements++;
	}
//	for(int i = (size); i > (old.size-1) ; i--){
//		elements[i] = old.elements[i];
//	}
}

template<class T>
int DynamicArray<T>::ReturnNumberOfElementsInArray(){

	return currentNumberOfElements;
}

template<class T>
void DynamicArray<T>::AddElement(T elem){
	if(currentNumberOfElements < size){
		elements[(size-1)-currentNumberOfElements] = elem;
//		T ** PTRarr = elements;
//		PTRarr+=(size-(currentNumberOfElements+1));
//
//		*PTRarr = elem;
		currentNumberOfElements++;

	}else{
		std::cout << "Array is FULL" << std::endl; // MIGHT NEED TO REMOVE BEFORE SUBMISSION
		//DynamicArray<T,S>::DynamicArray(this);
	}
}

template<class T>
void DynamicArray<T>::printAllElements(){
	T * PTRarr = elements;
	int empty = size - currentNumberOfElements;
	PTRarr+= empty;
	std::cout <<"Printed: " << std::endl;
	for(int i = 0 ; i<(currentNumberOfElements); i++ ){
		std::cout << *(PTRarr) << std::endl;
		PTRarr++;
	}

}






