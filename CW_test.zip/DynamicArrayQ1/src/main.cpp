/*
 * main.cpp
 *
 *  Created on: 20 Nov 2019
 *      Author: SUnNY
 */
#include <iostream>
#include "DynamicArray.cpp"
using namespace std;


int main()
{
	DynamicArray<int> a(4);

	cout << a.currentNumberOfElements << endl;
	a.AddElement(2);
	a.AddElement(9);
	a.AddElement(12);
	a.AddElement(124);

	cout << "a1st: "<< a.elements[0] << endl;
	cout << "a2nd: "<< a.elements[1] << endl;
	cout << "ard: "<< a.elements[2] << endl;
	cout << "aLast: "<< a.elements[3] << endl;

	cout << a.ReturnNumberOfElementsInArray() << endl;
	a.printAllElements();

	DynamicArray<int> b(a);

	cout << "b7: "<< b.elements[7] << endl;
	cout << "b6: "<< b.elements[6] << endl;
	cout << "b5: "<< b.elements[5] << endl;
	cout << "b4: "<< b.elements[4] << endl;
	cout << "b3: "<< b.elements[3] << endl;
	cout << "b2: "<< b.elements[2] << endl;
	cout << "b2: "<< b.elements[1] << endl;
	cout << "b2: "<< b.elements[0] << endl;
	b.printAllElements();
}



