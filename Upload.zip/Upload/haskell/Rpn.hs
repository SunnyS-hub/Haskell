import Data.List
import System.IO

step :: [Int] -> String -> [Int]
step stack str 
 | length stack == 0 = [read str :: Int]
 | str == "+" ||str == "-" || str == "*"= newStack
  where
   operand = take 2 stack
   unused = stack \\ operand
   arithmeticOperation = case str of
    "+" -> sum operand
    "-" -> (operand !! 1) - (operand !! 0)
    "*" -> product operand
   newStack = arithmeticOperation : unused

step stack str 
 = noOperationStack
  where 
   num = read str :: Int
   noOperationStack = num : stack





rpn :: [String] -> Int
rpn string
 = last $ foldl step [] string

pn :: [String] -> Int
pn string
 = -1*(rpn $ foldl fFun [] string)
  where 
   fFun xs "*" = "*" : xs
   fFun xs "+" = "+" : xs
   fFun xs "-" = "-" : xs
   fFun xs numberString = numberString : xs




rpnRec :: [String] -> Int
rpnRec [] = 0

rpnRec string = function [] string !! 0
  where 
    function st [] = st
    function st (x:xs) = function (step st x) xs


 --ERRORS (7 marks)
 
data RPNOut = RPNOut {
 success :: Int -> RPNOut,
 stuck :: [Int] -> [String] -> RPNOut,
 incomplete :: [Int] -> RPNOut 
}


step3 :: [Int] -> String -> Maybe [Int]
step3 (x:[]) "*" = Nothing
step3 (x:[]) "-" = Nothing
step3 (x:[]) "+" = Nothing
step3 [] "*" = Nothing
step3 [] "+" = Nothing
step3 [] "-" = Nothing
step3 (x:z:zs) "+" = Just [(x+z)]
step3 (x:z:zs) "*" = Just [(x*z)] 
step3 (x:z:zs) "-" = Just [(x-z)]  









