res(Nationality,Pet, House_colour).

h(A) :-
	length(A,3),
	member(res(spanish,jaguar,_),A),
	member(res(_,rabbit,_),A),
	member(res(french,_,black), A),
	A = [_,res(_,snail,_),res(japanese,_,_)],
	A = [_,res(_,snail,_), res(_,_,blue)],
	member(res(_,_,brown),A).

owner(RabbitOwner,Pet) :- 
	h(A),
	member(res(RabbitOwner,Pet,_),A).
	