/*
 * main.cpp
 *
 *  Created on: 20 Nov 2019
 *      Author: SUnNY
 */
#include <iostream>
#include <ctime>
#include "DynamicArray.cpp"
using namespace std;


int main()
{

	srand(time(0));

	/*INT ARRAY*/
	DynamicArray<int> intArray(5);
	for(int i = 0 ; i < 5 ; i++){
		intArray.AddElement((rand() % 100) + 1);
	}
	DynamicArray<int> intArrayBigger(intArray); // Make array size bigger
	intArrayBigger.AddElement(11);
	intArrayBigger.AddElement(86);
	intArrayBigger.AddElement(12);
	intArrayBigger.AddElement(44);
	intArrayBigger.AddElement(79);



	/*DOUBLE ARRAY*/
	DynamicArray<double> doubleArray(5);
	for(int i = 0 ; i< 5 ; i++){
		doubleArray.AddElement((rand() % 2) / (double ) (rand() + 1));
	}
	DynamicArray<double> doubleArrayBigger(doubleArray);
	doubleArrayBigger.AddElement(0.0000434);
	doubleArrayBigger.AddElement(0.234);
	doubleArrayBigger.AddElement(0.000994);
	doubleArrayBigger.AddElement(0.0021);
	doubleArrayBigger.AddElement(0.3534);


	cout << "Printing INTEGER array : " << endl;
	intArrayBigger.printAllElements();

	cout << "Printing DOUBLE array : " << endl;
	doubleArrayBigger.printAllElements();


	return 0;
}



