/*
 * DynamicArray.cpp
 *
 *  Created on: 20 Nov 2019
 *      Author: SUnNY
 */
#include "DynamicArray.h"


template<class T>
DynamicArray<T>::DynamicArray(int arrSize){
	size = arrSize;
	elements = new T[size];
	currentNumberOfElements = 0;
}

template<class T>
DynamicArray<T>::DynamicArray(const DynamicArray &old){

	size = (old.size * 2);
	elements = new T[size];
	currentNumberOfElements = 0;
	//copy elements from old to new
	//int counter = 0; // CAN USE CLASS MEMBER CURRENT_NUMBER_OF_ELEMENTS INSTEAD
	while(currentNumberOfElements<old.currentNumberOfElements){
		elements[(size-1)-currentNumberOfElements] = old.elements[(old.size -1) -currentNumberOfElements];
		//counter ++;
		currentNumberOfElements++;
	}
	// engaging destructor for old DynamicArray instance.
	old.~DynamicArray();
}

template<class T>
int DynamicArray<T>::ReturnNumberOfElementsInArray(){

	return currentNumberOfElements;
}

template<class T>
void DynamicArray<T>::AddElement(T elem){
	if(currentNumberOfElements < size){
		elements[(size-1)-currentNumberOfElements] = elem;
//		T ** PTRarr = elements;
//		PTRarr+=(size-(currentNumberOfElements+1));
//
//		*PTRarr = elem;
		currentNumberOfElements++;

	}else{
		std::cout << "Array is FULL" << std::endl; // MIGHT NEED TO REMOVE BEFORE SUBMISSION
	}
}

template<class T>
void DynamicArray<T>::printAllElements(){
	// checking if data type of type double
	if(sizeof(T) == 8){
		// if it is then print values in scientific notation.

		T * PTRarr = elements;
			int empty = size - currentNumberOfElements;
			PTRarr+= empty;
			for(int i = 0 ; i<(currentNumberOfElements); i++ ){
				//std::cout << *(PTRarr) << std::endl;
				printf("%e \n", (double)  *(PTRarr));
				PTRarr++;
			}
	}else{

		T * PTRarr = elements;
		int empty = size - currentNumberOfElements;
		PTRarr+= empty;

		for(int i = 0 ; i<(currentNumberOfElements); i++ ){
			std::cout << *(PTRarr) << std::endl;
			PTRarr++;
		}
	}

}

template<class T>
T DynamicArray<T>::operator [](int position){
	if(position < this->size){
		return this->elements[position];
	}else{
		std::cout << "Index " << position << " out of bound. Showing value in Last index of array: " ;
		return this->elements[size-1];
	}
}

template<class T>
DynamicArray<T>::~DynamicArray(){
	std::cout << "Copy destructor running" << endl;
	delete [] elements;
}






